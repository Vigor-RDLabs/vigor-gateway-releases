// Vigor Gateway - Vanilla JS Local Admin Web Console

document.addEventListener('DOMContentLoaded', () => {
    // Current application state
    let isAuthenticated = false;
    let configuredCameras = [];
    let scannedDevices = [];
    let editingCameraKey = null;

    // DOM Cache Elements
    const appContainer = document.getElementById('app');
    const loginModal = document.getElementById('modal-gateway-login');
    const loginForm = document.getElementById('login-form');
    const loginPass = document.getElementById('login-pass');
    
    const initPasswordModal = document.getElementById('modal-gateway-init');
    const initPasswordForm = document.getElementById('init-password-form');
    const initNewPass = document.getElementById('init-new-pass');
    const initConfirmPass = document.getElementById('init-confirm-pass');

    const infoGwId = document.getElementById('info-gw-id');
    const infoVersion = document.getElementById('info-version');
    const infoIp = document.getElementById('info-ip');
    const infoUptime = document.getElementById('info-uptime');
    const btnLogout = document.getElementById('btn-logout');

    const camerasCount = document.getElementById('cameras-count');
    const camerasTable = document.getElementById('cameras-table');
    const camerasTbody = document.getElementById('cameras-tbody');
    const camerasEmptyState = document.getElementById('cameras-empty-state');

    // Mode Selector Cards
    const cardOnvif = document.getElementById('mode-card-onvif');
    const cardRtsp = document.getElementById('mode-card-rtsp');
    const sectionOnvif = document.getElementById('section-onvif');
    const sectionRtspForm = document.getElementById('section-rtsp-form');

    // ONVIF Scan Elements
    const btnScan = document.getElementById('btn-scan');
    const lblScanTime = document.getElementById('lbl-scan-time');
    const scanEmptyState = document.getElementById('scan-empty-state');
    const scanLoadingState = document.getElementById('scan-loading-state');
    const scanTable = document.getElementById('scan-table');
    const scanResultsTbody = document.getElementById('scan-results-tbody');

    // ONVIF Credentials Modal
    const onvifAuthModal = document.getElementById('modal-onvif-auth');
    const onvifAuthForm = document.getElementById('onvif-auth-form');
    const onvifUser = document.getElementById('onvif-user');
    const onvifPass = document.getElementById('onvif-pass');
    const lblModalOnvifIp = document.getElementById('lbl-modal-onvif-ip');
    let selectedOnvifDevice = null;

    // RTSP Form Elements
    const formTitle = document.getElementById('form-title');
    const cameraForm = document.getElementById('camera-form');
    const camName = document.getElementById('cam-name');
    const camRtspUrl = document.getElementById('cam-rtsp-url');
    const camUsername = document.getElementById('cam-username');
    const camPassword = document.getElementById('cam-password');
    const camTransport = document.getElementById('cam-transport');
    const btnTestConnection = document.getElementById('btn-test-connection');
    const diagPanel = document.getElementById('diag-panel');
    const diagStatusBadge = document.getElementById('diag-status-badge');
    const diagDetailsText = document.getElementById('diag-details-text');
    const btnQuickAdd = document.getElementById('btn-quick-add');

    // Close Modals buttons
    document.querySelectorAll('.btn-close-modal, .btn-close-modal-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            onvifAuthModal.classList.add('hidden');
        });
    });

    // ── 1. Authentication & Boot Check ──────────────────────────────────────
    async function checkBootstrapState() {
        const res = await fetch('/api/v1/auth/bootstrap-state');
        if (!res.ok) {
            throw new Error('Failed to query bootstrap state');
        }
        const state = await res.json();
        return Boolean(state.requires_password_setup);
    }

    async function checkAuthStatus() {
        try {
            const res = await fetch('/api/v1/status');
            if (res.status === 401) {
                showLoginScreen();
            } else if (res.ok) {
                const status = await res.json();
                isAuthenticated = true;
                
                // Show dashboard
                loginModal.classList.add('hidden');
                appContainer.classList.remove('hidden');

                // Populate Gateway info
                infoGwId.textContent = status.gateway_id || 'N/A';
                infoVersion.textContent = status.version || '1.2.0';
                infoIp.textContent = window.location.hostname;
                infoUptime.textContent = status.uptime || 'N/A';

                // Initial fetch
                fetchConfiguredCameras();
            } else {
                showLoginScreen();
            }
        } catch (err) {
            showLoginScreen();
        }
    }

    function showLoginScreen() {
        isAuthenticated = false;
        appContainer.classList.add('hidden');
        initPasswordModal.classList.add('hidden');
        loginModal.classList.remove('hidden');
    }

    function showPasswordSetupScreen() {
        isAuthenticated = false;
        appContainer.classList.add('hidden');
        loginModal.classList.add('hidden');
        initPasswordModal.classList.remove('hidden');
    }

    // ── 2. Login & Password Change Event Handlers ────────────────────────────
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const password = loginPass.value;

        try {
            const res = await fetch('/api/v1/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ password })
            });

            if (res.ok) {
                const data = await res.json();
                loginPass.value = '';
                
                if (data.must_change_password) {
                    loginModal.classList.add('hidden');
                    initPasswordModal.classList.remove('hidden');
                } else {
                    initPasswordModal.classList.add('hidden');
                    checkAuthStatus();
                }
            } else {
                alert('Log in failed. Invalid local credentials.');
            }
        } catch (err) {
            alert('Server authentication error.');
        }
    });

    initPasswordForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const newPass = initNewPass.value;
        const confirmPass = initConfirmPass.value;

        if (newPass !== confirmPass) {
            alert('Passwords do not match.');
            return;
        }

        try {
            const res = await fetch('/api/v1/auth/change-password', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ new_password: newPass })
            });

            if (res.ok) {
                alert('Administrator password initialized successfully.');
                initNewPass.value = '';
                initConfirmPass.value = '';
                showLoginScreen();
            } else {
                alert('Failed to initialize administrator password.');
            }
        } catch (err) {
            alert('Error connecting to web server.');
        }
    });

    btnLogout.addEventListener('click', async () => {
        try {
            await fetch('/api/v1/auth/logout', { method: 'POST' });
        } catch (err) {}
        showLoginScreen();
    });

    // ── 3. Mode Toggle (ONVIF Scan vs Manual RTSP) ───────────────────────────
    cardOnvif.addEventListener('click', () => {
        cardOnvif.classList.add('active');
        cardRtsp.classList.remove('active');
        sectionOnvif.classList.remove('hidden');
        sectionRtspForm.classList.add('hidden');
        resetFormState();
    });

    cardRtsp.addEventListener('click', () => {
        cardRtsp.classList.add('active');
        cardOnvif.classList.remove('active');
        sectionRtspForm.classList.remove('hidden');
        sectionOnvif.classList.add('hidden');
        resetFormState();
    });

    btnQuickAdd.addEventListener('click', () => {
        cardRtsp.click();
    });

    function resetFormState() {
        formTitle.textContent = "Add Manual RTSP Stream";
        editingCameraKey = null;
        cameraForm.reset();
        diagPanel.classList.add('hidden');
    }

    // ── 4. Configured Cameras Operations ────────────────────────────────────
    async function fetchConfiguredCameras() {
        try {
            const res = await fetch('/api/v1/cameras');
            if (res.ok) {
                configuredCameras = await res.json();
                renderConfiguredCameras();
                if (scannedDevices.length > 0) {
                    renderScanResults();
                }
            }
        } catch (err) {
            console.error('Failed to fetch configured cameras', err);
        }
    }

    function renderConfiguredCameras() {
        camerasCount.textContent = configuredCameras.length;
        
        if (configuredCameras.length === 0) {
            camerasEmptyState.classList.remove('hidden');
            camerasTable.classList.add('hidden');
            return;
        }

        camerasEmptyState.classList.add('hidden');
        camerasTable.classList.remove('hidden');
        camerasTbody.innerHTML = '';

        configuredCameras.forEach(cam => {
            const tr = document.createElement('tr');
            
            // Icon / Preview column
            const typeClass = cam.type === 'ONVIF' ? 'badge-onvif' : 'badge-rtsp';
            const statusClass = cam.status === 'Online' ? 'badge-online' : 'badge-offline';
            
            tr.innerHTML = `
                <td>
                    <div class="cam-meta">
                        <strong class="cam-name-text">${escapeHtml(cam.name)}</strong>
                        <span class="cam-meta-sub">${cam.local_key}</span>
                    </div>
                </td>
                <td><span class="badge ${typeClass}">${cam.type || 'RTSP'}</span></td>
                <td>
                    <div class="address-cell">
                        <div>${escapeHtml(cam.rtsp_url)}</div>
                        <span class="address-cell-sub">${cam.ip ? 'IP: ' + cam.ip : 'Manual URL'}</span>
                    </div>
                </td>
                <td><span class="badge ${statusClass}">${cam.status || 'Offline'}</span></td>
                <td>${cam.last_seen || 'Never'}</td>
                <td>
                    <div class="actions-cell">
                        <button class="btn-icon btn-edit" data-key="${cam.local_key}" title="Edit Camera">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 1 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                        </button>
                        <button class="btn-icon btn-icon-delete btn-delete" data-key="${cam.local_key}" title="Delete Camera">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                        </button>
                    </div>
                </td>
            `;

            // Bind Edit Action
            tr.querySelector('.btn-edit').addEventListener('click', () => {
                editCamera(cam);
            });

            // Bind Delete Action
            tr.querySelector('.btn-delete').addEventListener('click', () => {
                deleteCamera(cam.local_key);
            });

            camerasTbody.appendChild(tr);
        });
    }

    function editCamera(cam) {
        editingCameraKey = cam.local_key;
        formTitle.textContent = `Edit Camera - ${cam.name}`;
        
        camName.value = cam.name;
        camRtspUrl.value = cam.rtsp_url;
        camUsername.value = cam.username || '';
        camPassword.value = ''; // Don't prefill password fields
        camTransport.value = cam.rtsp_transport || 'tcp';

        cardRtsp.click(); // Switch to form section
    }

    async function deleteCamera(localKey) {
        if (!confirm('Are you sure you want to remove this camera?')) {
            return;
        }

        try {
            const res = await fetch(`/api/v1/cameras/${localKey}`, {
                method: 'DELETE'
            });

            if (res.ok) {
                fetchConfiguredCameras();
            } else {
                alert('Failed to remove camera configuration.');
            }
        } catch (err) {
            alert('Communication error.');
        }
    }

    // Save Camera form submission
    cameraForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const payload = {
            name: camName.value,
            rtsp_url: camRtspUrl.value,
            username: camUsername.value,
            password: camPassword.value,
            rtsp_transport: camTransport.value
        };

        const method = editingCameraKey ? 'PUT' : 'POST';
        const endpoint = editingCameraKey ? `/api/v1/cameras/${editingCameraKey}` : '/api/v1/cameras';

        try {
            const res = await fetch(endpoint, {
                method: method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (res.ok) {
                cameraForm.reset();
                editingCameraKey = null;
                fetchConfiguredCameras();
                cardOnvif.click(); // Switch back to main dashboard
            } else {
                const errData = await res.json();
                alert('Failed to save camera configuration: ' + (errData.error || 'Unknown error'));
            }
        } catch (err) {
            alert('Failed to save camera details.');
        }
    });

    // ── 5. Live RTSP Connection Diagnostics ──────────────────────────────────
    btnTestConnection.addEventListener('click', async () => {
        const rtspUrl = camRtspUrl.value;
        if (!rtspUrl) {
            alert('Please specify an RTSP stream URL first.');
            return;
        }

        diagPanel.classList.remove('hidden');
        diagStatusBadge.textContent = "Checking...";
        diagStatusBadge.className = "badge";
        diagDetailsText.textContent = "Connecting to camera. Running avformat checks...";

        const payload = {
            rtsp_url: rtspUrl,
            username: camUsername.value,
            password: camPassword.value,
            rtsp_transport: camTransport.value
        };

        try {
            const res = await fetch('/api/v1/cameras/test', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (res.ok) {
                const data = await res.json();
                if (data.success) {
                    diagStatusBadge.textContent = "Connected";
                    diagStatusBadge.className = "badge badge-online";
                    diagDetailsText.textContent = `Successfully connected to RTSP stream!
Codec: ${data.codec || 'H.264'}
Resolution: ${data.width}x${data.height}
Framerate: ${data.fps ? data.fps.toFixed(1) + ' FPS' : 'N/A'}`;
                } else {
                    diagStatusBadge.textContent = "Failed";
                    diagStatusBadge.className = "badge badge-offline";
                    diagDetailsText.textContent = `Connection diagnostic failed.
Reachable: ${data.reachable ? 'Yes' : 'No'}
Authenticated: ${data.authenticated ? 'Yes' : 'No'}
Error detail: ${data.error || 'Connection timed out'}`;
                }
            } else {
                diagStatusBadge.textContent = "Error";
                diagStatusBadge.className = "badge badge-offline";
                diagDetailsText.textContent = "Failed to run diagnostic connection check.";
            }
        } catch (err) {
            diagStatusBadge.textContent = "Error";
            diagStatusBadge.className = "badge badge-offline";
            diagDetailsText.textContent = "Communication failure.";
        }
    });

    // ── 6. ONVIF Camera Scan & Discover ──────────────────────────────────────
    btnScan.addEventListener('click', async () => {
        scanEmptyState.classList.add('hidden');
        scanTable.classList.add('hidden');
        scanLoadingState.classList.remove('hidden');
        btnScan.disabled = true;

        try {
            const res = await fetch('/api/v1/onvif/scan', { method: 'POST' });
            scanLoadingState.classList.add('hidden');
            btnScan.disabled = false;

            if (res.ok) {
                const devices = await res.json();
                scannedDevices = devices;
                lblScanTime.textContent = "Last scan: " + new Date().toLocaleTimeString();
                
                if (scannedDevices.length === 0) {
                    scanEmptyState.classList.remove('hidden');
                    scanTable.classList.add('hidden');
                } else {
                    renderScanResults();
                }
            } else if (res.status === 409) {
                alert('A network scan is already running. Please wait.');
            } else {
                scanEmptyState.classList.remove('hidden');
                alert('Failed to complete network discovery scan.');
            }
        } catch (err) {
            scanLoadingState.classList.add('hidden');
            btnScan.disabled = false;
            scanEmptyState.classList.remove('hidden');
            alert('Scan error occurred.');
        }
    });

    function renderScanResults() {
        // Filter out devices that are already configured by matching IP addresses
        const filteredDevices = scannedDevices.filter(dev => {
            const alreadyAdded = configuredCameras.some(cam => {
                if (cam.ip === dev.ip) return true;
                if (cam.rtsp_url && cam.rtsp_url.includes(dev.ip)) return true;
                return false;
            });
            return !alreadyAdded;
        });

        if (filteredDevices.length === 0) {
            scanTable.classList.add('hidden');
            scanEmptyState.classList.remove('hidden');
            return;
        }

        scanTable.classList.remove('hidden');
        scanEmptyState.classList.add('hidden');
        scanResultsTbody.innerHTML = '';

        filteredDevices.forEach(dev => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td><strong>${escapeHtml(dev.model || 'ONVIF Camera')}</strong></td>
                <td><span class="address-cell">${dev.ip}</span></td>
                <td>ONVIF Generic</td>
                <td>2.0</td>
                <td>
                    <button class="btn btn-secondary btn-sm btn-add-onvif">Add</button>
                </td>
            `;

            tr.querySelector('.btn-add-onvif').addEventListener('click', () => {
                selectedOnvifDevice = dev;
                lblModalOnvifIp.textContent = dev.ip;
                onvifUser.value = 'admin';
                onvifPass.value = '';
                onvifAuthModal.classList.remove('hidden');
            });

            scanResultsTbody.appendChild(tr);
        });
    }

    // ONVIF Credential Form Submit -> Probes profiles -> Saves camera
    onvifAuthForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const username = onvifUser.value;
        const password = onvifPass.value;

        const btnProbe = document.getElementById('btn-probe-onvif');
        btnProbe.disabled = true;
        btnProbe.textContent = "Probing Device...";

        try {
            const res = await fetch('/api/v1/onvif/probe', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    xaddrs: selectedOnvifDevice.xaddrs,
                    username: username,
                    password: password
                })
            });

            btnProbe.disabled = false;
            btnProbe.textContent = "Connect Camera";

            if (res.ok) {
                const details = await res.json();
                if (details.success) {
                    onvifAuthModal.classList.add('hidden');
                    
                    // Auto-save the probed ONVIF camera
                    const savePayload = {
                        name: `${details.manufacturer || 'ONVIF'} ${details.model || 'Camera'}`,
                        rtsp_url: details.rtsp_url,
                        username: username,
                        password: password,
                        rtsp_transport: 'tcp',
                        ip: selectedOnvifDevice.ip,
                        type: 'ONVIF'
                    };

                    const saveRes = await fetch('/api/v1/cameras', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(savePayload)
                    });

                    if (saveRes.ok) {
                        fetchConfiguredCameras();
                        alert('ONVIF camera added successfully!');
                    } else {
                        alert('ONVIF parameters resolved, but saving configuration failed.');
                    }
                } else {
                    alert('Probe failed: ' + (details.error || 'Failed to authorize or retrieve profiles.'));
                }
            } else {
                alert('Failed to connect and probe the ONVIF device.');
            }
        } catch (err) {
            btnProbe.disabled = false;
            btnProbe.textContent = "Connect Camera";
            alert('ONVIF connection error.');
        }
    });

    // Helpers
    function escapeHtml(str) {
        if (!str) return '';
        return str.replace(/&/g, "&amp;")
                  .replace(/</g, "&lt;")
                  .replace(/>/g, "&gt;")
                  .replace(/"/g, "&quot;")
                  .replace(/'/g, "&#039;");
    }

    // Run startup check
    (async () => {
        try {
            if (await checkBootstrapState()) {
                showPasswordSetupScreen();
                return;
            }
        } catch (err) {}
        checkAuthStatus();
    })();
});
